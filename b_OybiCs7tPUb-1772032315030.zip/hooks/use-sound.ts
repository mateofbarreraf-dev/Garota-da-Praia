"use client"

import { useCallback, useRef } from "react"

type SoundType = "click" | "hover" | "success" | "pop"

export function useSound() {
  const audioContextRef = useRef<AudioContext | null>(null)

  const getContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioContext()
    }
    return audioContextRef.current
  }, [])

  const playSound = useCallback(
    (type: SoundType) => {
      try {
        const ctx = getContext()
        const oscillator = ctx.createOscillator()
        const gainNode = ctx.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(ctx.destination)

        const now = ctx.currentTime

        switch (type) {
          case "click":
            oscillator.type = "sine"
            oscillator.frequency.setValueAtTime(800, now)
            oscillator.frequency.exponentialRampToValueAtTime(600, now + 0.08)
            gainNode.gain.setValueAtTime(0.12, now)
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.1)
            oscillator.start(now)
            oscillator.stop(now + 0.1)
            break

          case "hover":
            oscillator.type = "sine"
            oscillator.frequency.setValueAtTime(1200, now)
            oscillator.frequency.exponentialRampToValueAtTime(1400, now + 0.05)
            gainNode.gain.setValueAtTime(0.04, now)
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.06)
            oscillator.start(now)
            oscillator.stop(now + 0.06)
            break

          case "success":
            oscillator.type = "sine"
            oscillator.frequency.setValueAtTime(523, now)
            oscillator.frequency.setValueAtTime(659, now + 0.1)
            oscillator.frequency.setValueAtTime(784, now + 0.2)
            gainNode.gain.setValueAtTime(0.1, now)
            gainNode.gain.setValueAtTime(0.1, now + 0.2)
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.35)
            oscillator.start(now)
            oscillator.stop(now + 0.35)
            break

          case "pop":
            oscillator.type = "sine"
            oscillator.frequency.setValueAtTime(1000, now)
            oscillator.frequency.exponentialRampToValueAtTime(300, now + 0.08)
            gainNode.gain.setValueAtTime(0.15, now)
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.1)
            oscillator.start(now)
            oscillator.stop(now + 0.1)
            break
        }
      } catch {
        // Silently fail if audio context is not available
      }
    },
    [getContext]
  )

  return { playSound }
}
