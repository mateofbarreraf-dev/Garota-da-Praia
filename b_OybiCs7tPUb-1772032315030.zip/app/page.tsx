import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { CatalogSection } from "@/components/catalog-section"
import { AboutSection } from "@/components/about-section"
import { InstagramSection } from "@/components/instagram-section"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/floating-bubbles"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <CatalogSection />
        <AboutSection />
        <InstagramSection />
      </main>
      <Footer />
      <FloatingBubbles />
    </div>
  )
}
