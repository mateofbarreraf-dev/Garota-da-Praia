"use client"

import Image from "next/image"
import { useSound } from "@/hooks/use-sound"

export function HeroSection() {
  const { playSound } = useSound()
  return (
    <section className="relative min-h-[90vh] overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1771983317119e%20%281%29-NkvbAi3iUetQ7nhSYH0KZc3fE6uC78.png"
          alt="Modelos na praia com biquinis Garota da Praia"
          fill
          className="object-cover object-[center_20%]"
          sizes="100vw"
          priority
          quality={90}
        />
        {/* Overlay gradiente mais sofisticado */}
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-foreground/20" />
      </div>

      <div className="relative mx-auto flex max-w-7xl flex-col items-center px-6 py-28 lg:flex-row lg:items-center lg:px-8 lg:py-0 lg:min-h-[90vh]">
        {/* Left: text content */}
        <div className="flex flex-1 flex-col items-center gap-8 text-center lg:items-start lg:pr-16 lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-5 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary backdrop-blur-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            {'Nova Coleção 2026'}
          </span>
          <h1 className="font-serif text-5xl font-bold leading-[1.05] text-card md:text-6xl lg:text-8xl text-balance">
            {'Verão o'}<br />Ano Todo
          </h1>
          <p className="max-w-lg text-base leading-relaxed text-card/80 lg:text-lg">
            {'Descubra peças únicas feitas com amor, conforto e muito estilo para você brilhar na praia, piscina ou onde quiser.'}
          </p>
          <div className="flex flex-col items-center gap-4 sm:flex-row lg:items-start">
            <a
              href="#sobre"
              onClick={() => playSound("click")}
              onMouseEnter={() => playSound("hover")}
              className="inline-flex items-center gap-2 rounded-full bg-primary px-10 py-4 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:bg-primary/90 hover:shadow-xl hover:shadow-primary/30 hover:scale-105"
            >
              {'Conheça Nossa História'}
            </a>
            <a
              href="https://wa.me/5522999406681"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound("success")}
              onMouseEnter={() => playSound("hover")}
              className="inline-flex items-center gap-2 rounded-full border border-card/25 px-10 py-4 text-sm font-semibold text-card transition-all backdrop-blur-sm hover:bg-card/10 hover:border-card/40 hover:scale-105"
            >
              Fale Conosco
            </a>
          </div>
        </div>

        {/* Right: logo */}
        <div className="mt-16 flex flex-1 items-center justify-center lg:mt-0">
          <div className="relative">
            <div className="absolute -inset-12 rounded-full bg-primary/10 blur-[60px]" />
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lOGO-3xW9umXDaa2VIXRcxsN1t5mZHRPz2t.png"
              alt="Garota da Praia logo"
              width={420}
              height={420}
              className="relative h-52 w-52 drop-shadow-2xl md:h-64 md:w-64 lg:h-80 lg:w-80 object-contain"
              priority
            />
          </div>
        </div>
      </div>

      {/* Bottom decorative line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
    </section>
  )
}
