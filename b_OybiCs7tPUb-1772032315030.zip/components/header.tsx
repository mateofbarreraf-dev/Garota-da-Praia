"use client"

import { useState, useEffect } from "react"
import { Instagram, Menu, X, ShoppingBag } from "lucide-react"
import Image from "next/image"
import { useSound } from "@/hooks/use-sound"

const navLinks = [
  { label: "Inicio", href: "#" },
  { label: "Catalogo", href: "#catalogo" },
  { label: "Sobre Nos", href: "#sobre" },
  { label: "Instagram", href: "#instagram" },
  { label: "Contato", href: "#contato" },
]

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { playSound } = useSound()

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/98 shadow-md backdrop-blur-md border-b border-border/50"
          : "bg-background border-b border-border"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 lg:px-8 lg:py-4">
        {/* Mobile menu button */}
        <button
          className="lg:hidden text-foreground/70 hover:text-foreground transition-colors"
          onClick={() => { playSound("click"); setMenuOpen(!menuOpen) }}
          onMouseEnter={() => playSound("hover")}
          aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        {/* Logo */}
        <a href="#" className="flex items-center gap-3 group shrink-0">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lOGO-3xW9umXDaa2VIXRcxsN1t5mZHRPz2t.png"
            alt=""
            width={44}
            height={44}
            className="h-9 w-9 lg:h-10 lg:w-10 transition-transform duration-300 group-hover:scale-105"
          />
          <span className="font-serif text-lg font-bold tracking-tight text-[#3730A3] sm:text-xl lg:text-2xl">
            Garota Da Praia
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-8" aria-label="Menu principal">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => playSound("click")}
              onMouseEnter={() => playSound("hover")}
              className="relative text-[13px] font-medium tracking-wide text-foreground/60 transition-colors hover:text-foreground after:absolute after:-bottom-1 after:left-0 after:h-[1.5px] after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-3">
          <a
            href="https://www.instagram.com/garotadapraia.centrosaquarema/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            onClick={() => playSound("pop")}
            onMouseEnter={() => playSound("hover")}
            className="text-foreground/50 transition-colors hover:text-primary"
          >
            <Instagram className="h-[18px] w-[18px]" />
          </a>
          <a
            href="https://wa.me/c/5521997236876"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playSound("success")}
            onMouseEnter={() => playSound("hover")}
            className="hidden sm:inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2 text-xs font-semibold text-primary-foreground transition-all hover:bg-primary/90 hover:scale-105"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            Comprar Agora
          </a>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <nav
          className="lg:hidden border-t border-border/50 bg-background/98 backdrop-blur-md px-4 pb-6 pt-3"
          aria-label="Menu mobile"
        >
          <ul className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <li key={link.label}>
                <a
                  href={link.href}
                  className="block rounded-lg px-4 py-3 text-sm font-medium text-foreground/70 transition-colors hover:bg-secondary hover:text-foreground"
                  onClick={() => { playSound("click"); setMenuOpen(false) }}
                  onMouseEnter={() => playSound("hover")}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-4 px-4">
            <a
              href="https://wa.me/c/5521997236876"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound("success")}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground"
            >
              <ShoppingBag className="h-4 w-4" />
              Comprar Agora
            </a>
          </div>
        </nav>
      )}
    </header>
  )
}
