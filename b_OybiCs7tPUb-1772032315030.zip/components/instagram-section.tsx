"use client"

import Image from "next/image"
import { Instagram } from "lucide-react"
import { useSound } from "@/hooks/use-sound"

const feedImages = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1769553049145-v16LskK5pK2hvtg0DS6XgLByrFB6ca.png",
    alt: "Top de biquini preto com laco frontal",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20-2_1600x2000%2Bfill_ffffff-GQKigsgCzZLOjP4pjoNcfNUs2rOHnJ.webp",
    alt: "Calcinha de biquini azul royal com amarracao - vista traseira",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/68-1-min-1_1600x2000%2Bfill_ffffff-3MwmgRDohBC7E1zAZaoTo32LhFJhQf.webp",
    alt: "Calcinha de biquini turquesa",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/89-2-min-1_1600x2000%2Bfill_ffffff-6XId2zgjI0LccbWx7OCAcN3VnW4cig.webp",
    alt: "Calcinha de biquini verde",
  },
]

export function InstagramSection() {
  const { playSound } = useSound()
  return (
    <section className="relative py-20 lg:py-28 overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%202%20de%20jan.%20de%202026%2C%2014_43_54-tvnNdUNRvweNdi1JZb3r5R1XNAJyE1.png"
          alt=""
          fill
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-foreground/75 backdrop-blur-sm" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="mb-14 text-center">
          <div className="inline-flex items-center gap-2.5 rounded-full border border-card/15 bg-card/5 px-4 py-2 backdrop-blur-sm">
            <Instagram className="h-4 w-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-card/80">
              Instagram
            </span>
          </div>
          <h2 className="mt-6 font-serif text-3xl font-bold text-card md:text-4xl lg:text-5xl text-balance">
            Acompanhe nosso dia a dia
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-card/60 leading-relaxed">
            Siga nosso perfil para novidades, lancamentos e inspiracoes de looks
            de praia.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
          {feedImages.map((img, index) => (
            <a
              key={index}
              href="https://www.instagram.com/garotadapraia.centrosaquarema/"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound("pop")}
              onMouseEnter={() => playSound("hover")}
              className="group relative aspect-square overflow-hidden rounded-2xl ring-1 ring-card/10"
            >
              <Image
                src={img.src}
                alt={img.alt}
                fill
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                sizes="(max-width: 768px) 50vw, 25vw"
              />
              <div className="absolute inset-0 bg-foreground/0 transition-all duration-500 group-hover:bg-foreground/40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-card/0 backdrop-blur-none transition-all duration-500 group-hover:bg-card/15 group-hover:backdrop-blur-sm scale-50 opacity-0 group-hover:scale-100 group-hover:opacity-100">
                  <Instagram className="h-5 w-5 text-card" />
                </div>
              </div>
            </a>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="https://www.instagram.com/garotadapraia.centrosaquarema/"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playSound("pop")}
            onMouseEnter={() => playSound("hover")}
            className="inline-flex items-center gap-3 rounded-full border border-card/20 bg-card/5 px-8 py-3.5 text-sm font-medium text-card/90 backdrop-blur-md transition-all duration-300 hover:bg-card/15 hover:border-card/35 hover:text-card"
          >
            <Instagram className="h-4 w-4" />
            @garotadapraia.centrosaquarema
          </a>
        </div>
      </div>
    </section>
  )
}
