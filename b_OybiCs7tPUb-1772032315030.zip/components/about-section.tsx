import Image from "next/image"

export function AboutSection() {
  return (
    <section id="sobre" className="relative overflow-hidden bg-[#3730A3] py-24 lg:py-32">
      {/* Subtle background pattern */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 -top-40 h-[500px] w-[500px] rounded-full bg-[#FF69B4]/8 blur-[120px]" />
        <div className="absolute -bottom-40 -right-40 h-[500px] w-[500px] rounded-full bg-[#FF69B4]/6 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 lg:px-8">
        <div className="grid items-center gap-16 lg:grid-cols-2 lg:gap-20">
          {/* Left: Logo + Brand visual */}
          <div className="flex flex-col items-center gap-10">
            <div className="relative">
              {/* Glow behind the logo */}
              <div className="absolute inset-0 scale-110 rounded-full bg-[#FF69B4]/15 blur-[60px]" />
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lOGO-3xW9umXDaa2VIXRcxsN1t5mZHRPz2t.png"
                alt="Logo Garota Da Praia - borboleta rosa"
                width={280}
                height={280}
                className="relative h-48 w-48 drop-shadow-2xl md:h-64 md:w-64 lg:h-72 lg:w-72"
              />
            </div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/nome-ekx9xt71AIfzy6LeTlZYwrNCo0duTR.png"
              alt="Garota Da Praia"
              width={320}
              height={64}
              className="h-10 w-auto md:h-12 lg:h-14"
            />
          </div>

          {/* Right: Story text */}
          <div className="flex flex-col gap-8">
            <div>
              <span className="inline-flex items-center gap-2.5 rounded-full bg-white/10 px-5 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-white/70 backdrop-blur-sm">
                <span className="h-1.5 w-1.5 rounded-full bg-[#FF69B4]" />
                Nossa Historia
              </span>
            </div>

            <h2 className="font-serif text-3xl font-bold leading-tight text-white md:text-4xl lg:text-5xl text-balance">
              Sobre a Gente
            </h2>

            <div className="flex flex-col gap-6">
              <p className="text-base leading-relaxed text-white/80 md:text-lg">
                {'Bem-vindo à '}
                <strong className="font-semibold text-white">Garota da Praia</strong>
                {', sua referência em moda praia em Vila, Saquarema há mais de uma década e meia!'}
              </p>

              <p className="text-base leading-relaxed text-white/70 md:text-lg">
                {'Desde 1998, temos nos dedicado a proporcionar a nossos clientes uma experiência única de estilo e conforto à beira-mar. Nossa loja é um destino emblemático para os amantes do sol e do mar, onde a tradição encontra as últimas tendências.'}
              </p>

              <p className="text-base leading-relaxed text-white/70 md:text-lg">
                {'Com uma seleção cuidadosa das melhores marcas e designs exclusivos, estamos comprometidos em oferecer peças que combinam qualidade excepcional, elegância e praticidade.'}
              </p>
            </div>

            {/* Stats */}
            <div className="mt-4 grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
              <div className="flex flex-col gap-1">
                <span className="font-serif text-2xl font-bold text-[#FF69B4] md:text-3xl">
                  15+
                </span>
                <span className="text-xs uppercase tracking-wider text-white/50">
                  Anos de historia
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-serif text-2xl font-bold text-[#FF69B4] md:text-3xl">
                  {'Vila'}
                </span>
                <span className="text-xs uppercase tracking-wider text-white/50">
                  Saquarema, RJ
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-serif text-2xl font-bold text-[#FF69B4] md:text-3xl">
                  100%
                </span>
                <span className="text-xs uppercase tracking-wider text-white/50">
                  Moda praia
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
