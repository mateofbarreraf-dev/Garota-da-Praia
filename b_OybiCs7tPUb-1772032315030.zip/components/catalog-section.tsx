"use client"

import Image from "next/image"
import { useState } from "react"
import { useSound } from "@/hooks/use-sound"
import { ShieldCheck, Droplets, Sun } from "lucide-react"

const whatsappLink = "https://wa.me/5521997236876"

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

interface CatalogProduct {
  id: number
  name: string
  price: string
  priceNum: number
  image: string
  alt: string
  category: "tops" | "bottoms"
  highlights: string[]
  composition?: string
}

const catalogProducts: CatalogProduct[] = [
  {
    id: 1,
    name: "Top Curtininha",
    price: "R$ 50,00",
    priceNum: 50,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Azul%20caneta%20%282%29.png-Zqlsbjw0imlSuaNfJ8Ad2WGw1LqjD5.jpeg",
    alt: "Top Curtininha azul royal com triangulos moveis e amarracao no pescoco",
    category: "tops",
    highlights: [
      "Triangulos moveis com ajuste de cobertura",
      "Amarracao no pescoco e costas",
      "Design minimalista e atemporal",
    ],
  },
  {
    id: 2,
    name: "Tanga Laco Fino",
    price: "R$ 58,00",
    priceNum: 58,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Azul%20caneta%20%285%29.png-XZo3mJxxVS0MIVJZ5qaSGMzIq0C8AQ.jpeg",
    alt: "Tanga Laco Fino azul royal com amarracao lateral e ponteiras douradas",
    category: "bottoms",
    highlights: [
      "Corte tanga que valoriza a silhueta",
      "Amarracao lateral com ajuste perfeito",
      "Ponteiras douradas premium",
    ],
    composition: "90% Poliamida, 10% Elastano",
  },
  {
    id: 3,
    name: "Busto Confort",
    price: "R$ 89,00",
    priceNum: 89,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1769553049145-Xt0YtrR9ZQcGj21lyPe60yBRTqpvox.png",
    alt: "Busto Confort preto com alcas largas e detalhe frontal torcido",
    category: "tops",
    highlights: [
      "Sustentacao superior com alcas largas",
      "Detalhe frontal torcido exclusivo",
      "Maximo conforto e seguranca",
    ],
    composition: "90% Poliamida, 10% Elastano",
  },
  {
    id: 4,
    name: "Hot Pant Drapeada",
    price: "R$ 78,00",
    priceNum: 78,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1769553081990-UzRtuloFeRCxaa1wIsDvxbohdvnTOj.png",
    alt: "Hot Pant Drapeada preta com cintura alta e drapeado lateral",
    category: "bottoms",
    highlights: [
      "Cintura alta que valoriza a silhueta",
      "Drapeado lateral esculpe as curvas",
      "Corte anatomico com total cobertura",
    ],
    composition: "90% Poliamida, 10% Elastano",
  },
  {
    id: 5,
    name: "Top Halter",
    price: "R$ 85,00",
    priceNum: 85,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vermelho.png-I2E1tkYSm9S0Urtxf47nbmPqwjkWop.jpeg",
    alt: "Top Halter vermelho com decote em V e tripla faixa na base",
    category: "tops",
    highlights: [
      "Alcas halter com efeito push-up natural",
      "Decote em V feminino e elegante",
      "Base com tripla faixa exclusiva",
    ],
    composition: "90% Poliamida, 10% Elastano",
  },
  {
    id: 6,
    name: "Tanga Passion",
    price: "R$ 85,00",
    priceNum: 85,
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vermelho%20%282%29.png-rFF0NtlSzE25XQS7erWdxVzGW0Cmhk.jpeg",
    alt: "Tanga Passion vermelha com cos largo drapeado e fivela dourada",
    category: "bottoms",
    highlights: [
      "Cos largo com altura media e seguranca",
      "Fivela metalica dourada exclusiva",
      "Cos drapeado com textura refinada",
    ],
    composition: "90% Poliamida, 10% Elastano",
  },
]

type Filter = "all" | "tops" | "bottoms"

export function CatalogSection() {
  const { playSound } = useSound()
  const [filter, setFilter] = useState<Filter>("all")
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  const filtered = filter === "all"
    ? catalogProducts
    : catalogProducts.filter((p) => p.category === filter)

  const filters: { label: string; value: Filter }[] = [
    { label: "Todos", value: "all" },
    { label: "Tops", value: "tops" },
    { label: "Bottoms", value: "bottoms" },
  ]

  return (
    <section id="catalogo" className="relative overflow-hidden bg-secondary/30">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />

      <div className="relative mx-auto max-w-7xl px-4 py-20 lg:px-8 lg:py-28">
        {/* Header */}
        <div className="mb-12 text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/8 px-5 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Catalogo Completo
          </span>
          <h2 className="mt-5 font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl text-balance">
            Colecao Exclusiva
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground leading-relaxed">
            Pecas feitas com tecido premium, protecao UV 50+ e tecnologia Soft Touch.
            Escolha a sua e fale direto conosco pelo WhatsApp.
          </p>
        </div>

        {/* Tech badges */}
        <div className="mb-10 flex flex-wrap items-center justify-center gap-3">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-xs font-medium text-muted-foreground">
            <Sun className="h-3.5 w-3.5 text-amber-500" />
            UV 50+
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-xs font-medium text-muted-foreground">
            <Droplets className="h-3.5 w-3.5 text-sky-500" />
            Secagem Rapida
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-xs font-medium text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
            Soft Touch
          </span>
        </div>

        {/* Filters */}
        <div className="mb-10 flex items-center justify-center gap-2">
          {filters.map((f) => (
            <button
              key={f.value}
              onClick={() => { playSound("click"); setFilter(f.value) }}
              onMouseEnter={() => playSound("hover")}
              className={`rounded-full px-6 py-2.5 text-sm font-medium transition-all duration-200 ${
                filter === f.value
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                  : "bg-card text-muted-foreground border border-border hover:text-foreground hover:border-foreground/20"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((product) => (
            <article
              key={product.id}
              className="group relative flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card transition-all duration-500 hover:shadow-2xl hover:shadow-foreground/5 hover:-translate-y-1"
              onMouseEnter={() => setHoveredId(product.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden bg-secondary/50">
                <Image
                  src={product.image}
                  alt={product.alt}
                  fill
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                {/* Price badge */}
                <div className="absolute top-4 right-4 rounded-full bg-card/95 px-4 py-1.5 shadow-lg backdrop-blur-sm">
                  <span className="text-sm font-bold text-foreground">{product.price}</span>
                </div>
                {/* Category badge */}
                <div className="absolute top-4 left-4 rounded-full bg-primary/90 px-3 py-1 shadow-lg backdrop-blur-sm">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
                    {product.category === "tops" ? "Top" : "Bottom"}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="flex flex-1 flex-col p-5 lg:p-6">
                <h3 className="font-serif text-xl font-bold text-foreground lg:text-2xl">
                  {product.name}
                </h3>

                {/* Highlights */}
                <ul className="mt-3 flex flex-col gap-2">
                  {product.highlights.map((h, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-relaxed">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary/60" />
                      {h}
                    </li>
                  ))}
                </ul>

                {/* Composition */}
                {product.composition && (
                  <p className="mt-3 text-xs text-muted-foreground/70">
                    {product.composition}
                  </p>
                )}

                {/* CTA */}
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => playSound("success")}
                  onMouseEnter={() => playSound("hover")}
                  className="mt-5 flex items-center justify-center gap-2.5 rounded-xl bg-[#25D366] px-5 py-3.5 text-sm font-bold text-[#fff] shadow-md shadow-[#25D366]/20 transition-all duration-200 hover:bg-[#1ebe5d] hover:shadow-lg hover:shadow-[#25D366]/30 active:scale-[0.98]"
                >
                  <WhatsAppIcon className="h-4.5 w-4.5" />
                  <span>Quero Este! Falar no WhatsApp</span>
                </a>
              </div>
            </article>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="mx-auto max-w-lg rounded-2xl border border-border/60 bg-card p-8 shadow-lg">
            <h3 className="font-serif text-xl font-bold text-foreground lg:text-2xl text-balance">
              Nao encontrou o que procura?
            </h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
              Temos mais cores e modelos disponiveis. Fale com a gente e monte seu biquini ideal!
            </p>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound("success")}
              onMouseEnter={() => playSound("hover")}
              className="mt-5 inline-flex items-center gap-2.5 rounded-full bg-primary px-8 py-3.5 text-sm font-bold text-primary-foreground shadow-md shadow-primary/20 transition-all hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/30 hover:scale-105"
            >
              <WhatsAppIcon className="h-4 w-4" />
              Ver Catalogo Completo
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
