"use client"

import Image from "next/image"
import { useSound } from "@/hooks/use-sound"

const products = [
  {
    id: 1,
    name: "Top Laco Preto",
    price: "R$ 89,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1769553049145%20%281%29-bFvCd33HJFVG1hbQAGvP74NnbZK7ZW.png",
    alt: "Top de biquini preto com detalhe de laco frontal",
  },
  {
    id: 2,
    name: "Calcinha Fio Preta",
    price: "R$ 69,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/168-min-1_1600x2000%2Bfill_ffffff-2oLLe7w0MTPsvcDPwgreasurxAdlaZ.webp",
    alt: "Calcinha de biquini preta estilo fio com laterais franzidas",
  },
  {
    id: 3,
    name: "Hot Pants Preta",
    price: "R$ 79,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1769553081990-JXRAp5sqRILfp6hepBoRM9kdgHWMaj.png",
    alt: "Calcinha hot pants preta com drapeado lateral",
  },
  {
    id: 4,
    name: "Calcinha Amarracao Azul",
    price: "R$ 74,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/19-2_1600x2000%2Bfill_ffffff-LKNL8Ev357dOh91ryu6Qdhb2IwOlCJ.webp",
    alt: "Calcinha de biquini azul royal com amarracao lateral",
  },
  {
    id: 5,
    name: "Calcinha Fio Azul Royal",
    price: "R$ 69,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/25-3-min-1_1600x2000%2Bfill_ffffff-ROmL0uBq6bp7b6X5ztkvL3o3iKFbxX.webp",
    alt: "Calcinha de biquini azul royal estilo fio",
  },
  {
    id: 6,
    name: "Calcinha Fio Turquesa",
    price: "R$ 69,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/68-1-min-1_1600x2000%2Bfill_ffffff-3MwmgRDohBC7E1zAZaoTo32LhFJhQf.webp",
    alt: "Calcinha de biquini turquesa estilo fio com laterais franzidas",
  },
  {
    id: 7,
    name: "Calcinha Fio Verde",
    price: "R$ 69,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/89-2-min-1_1600x2000%2Bfill_ffffff-6XId2zgjI0LccbWx7OCAcN3VnW4cig.webp",
    alt: "Calcinha de biquini verde estilo fio com laterais franzidas",
  },
  {
    id: 8,
    name: "Calcinha Fio Uva",
    price: "R$ 69,90",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/39-1-min-1_1600x2000%2Bfill_ffffff-5klqxhfpaWcKS4GwTBu0GeanSDUhfi.webp",
    alt: "Calcinha de biquini roxa uva estilo fio",
  },
]

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

export function ProductGrid() {
  const { playSound } = useSound()
  const catalogUrl = "https://wa.me/c/5521997236876"

  return (
    <section id="catalogo" className="mx-auto max-w-7xl px-4 py-20 lg:px-8 lg:py-28">
      <div className="mb-14 text-center">
        <span className="inline-flex items-center gap-2 rounded-full bg-primary/8 px-5 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-primary" />
          Catalogo
        </span>
        <h2 className="mt-5 font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl text-balance">
          Nossas Pecas
        </h2>
        <p className="mx-auto mt-4 max-w-lg text-muted-foreground leading-relaxed">
          Feitas a mao com tecidos de alta qualidade e protecao UV. Escolha seu
          modelo favorito e fale direto conosco pelo WhatsApp.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 lg:gap-6">
        {products.map((product) => (
          <article
            key={product.id}
            className="group flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card transition-all duration-300 hover:shadow-xl hover:shadow-foreground/5 hover:-translate-y-1"
          >
            <div className="relative aspect-[4/5] overflow-hidden bg-secondary">
              <Image
                src={product.image}
                alt={product.alt}
                fill
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
              />
            </div>
            <div className="flex flex-1 flex-col gap-2 p-4 lg:p-5">
              <h3 className="text-sm font-medium text-foreground/80 lg:text-base">
                {product.name}
              </h3>
              <p className="text-lg font-bold text-foreground">{product.price}</p>
              <a
                href={catalogUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound("success")}
                onMouseEnter={() => playSound("hover")}
                className="mt-auto flex items-center justify-center gap-2.5 rounded-xl bg-[#25D366] px-4 py-3 text-sm font-semibold text-[#fff] transition-all duration-200 hover:bg-[#1ebe5d] active:scale-[0.98]"
              >
                <WhatsAppIcon className="h-4 w-4" />
                <span>Comprar</span>
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
